# CANCMD
CBUS DCC command station for model railway control

This firmware supports the following hardware by building wth conditional compilation:

CANBC - Original first generation MERG command station with CBUS daughter board
CANCMD - MERG command station as designed by Mike Bolton
CANCSB - Command Stattion-Booster, based on CANCMD with the addition of a 3A track output
